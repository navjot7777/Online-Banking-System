import java.io.IOException;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * this is login processor servlet, that handles login requests.
 * if user details are correct then it lands user to otp page, else it redirects user to login page
 */
public class LoginProcessor extends HttpServlet {
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		
		// email and password entered by uer
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		
		// is user details are found, then generate otp and redirect user to enter otp
		if (Validate.checkUser(email, password, request)) {
			// generating otp
			String generatedOtp = generateOTP(6);
			
			// sending email to user for otp
			sendEmail(email, "OTP", "OTP for login: " + generatedOtp);
			
			// adding otp in session to validate otp
			request.getSession().setAttribute("otp", generatedOtp);
			request.getSession().setAttribute("email", email);
			request.getSession().setAttribute("otpError", null);
			
			// redirecting user to enter otp
			RequestDispatcher rs = request.getRequestDispatcher("otp.jsp");
			rs.forward(request, response);
		} else {
			// if user entered wrong details then redirect user to login again
			request.setAttribute("errorMessage", "Username or Password incorrect.");
			RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
			rs.forward(request, response);
		}
	}

	/**
	 * this method sends email to user.
	 * 
	 * @param to: email id to which email is required to send
	 * @param subject: subject of email
	 * @param message_: content of email
	 */
	public static void sendEmail(String to, String subject, String message_) {
		String host = "smtp.gmail.com";
		Properties properties = System.getProperties();
		properties.put("mail.smtp.host", host);
		properties.put("mail.smtp.port", "465");
		properties.put("mail.smtp.ssl.enable", "true");
		properties.put("mail.smtp.auth", "true");
		Session session = Session.getInstance(properties,
				new javax.mail.Authenticator() {
					protected PasswordAuthentication getPasswordAuthentication() {
						return new PasswordAuthentication(Constants.USER_EMAIL,
								Constants.USER_EMAIL_PASSWORD);
					}
				});
		session.setDebug(true);
		try {
			MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(Constants.USER_EMAIL));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));
			message.setSubject(subject);
			message.setText(message_);
			Transport.send(message);
		} catch (MessagingException mex) {
			mex.printStackTrace();
		}
	}

	/**
	 * this method is used to generate random string.
	 * 
	 * @param length: length of random string to be generated 
	 * @return
	 */
	public static String generateOTP(int length) {
		Random obj = new Random();
		String otp = "";
		for (int i = 0; i < length; i++) {
			otp += obj.nextInt(10);
		}
		return otp;
	}
}