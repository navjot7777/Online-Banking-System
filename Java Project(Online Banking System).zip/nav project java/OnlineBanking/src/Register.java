import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Types;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;
/**
 * this servlet registers user. it validates is user already exist.
 * if user already exists then redirect user to login, else generate password and send email to new user
 * and redirect user to login page
 */
@MultipartConfig
public class Register extends HttpServlet {
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String email = request.getParameter("email");
        // check if user already exists
        if(Validate.isUserExist(email)) {
        	request.setAttribute("feedback", "User already exist. Please login to proceed.");
        } else {
        	String fileName = null;
        	InputStream is = null;
        	for (Part part : request.getParts()) {
        		fileName = extractFileName(part);
    			if (fileName != null && fileName.length() > 0) {
    				is = part.getInputStream();
    			}
    		}
        	
        	// else create new user with random password and send email to user
        	String password = LoginProcessor.generateOTP(10);
        	Connection con = DBUtils.getConnection();
            try {
            	PreparedStatement ps = con.prepareStatement("INSERT INTO "+Constants.DB_TABLENAME_USERS+"(name, email, password, mobile, balance, sin_no, address, document, file_name) VALUES (?,?,?,?,?,?,?,?,?)");
				ps.setString(1, request.getParameter("name"));
				ps.setString(2, email);
	            ps.setString(3, password);
	            ps.setString(4, request.getParameter("mobile"));
	            ps.setString(5, request.getParameter("amount"));
	            ps.setString(6, request.getParameter("sinNo"));
	            ps.setString(7, request.getParameter("address"));
	            if(is != null) {
	            	ps.setBlob(8, is);
	            	ps.setString(9, fileName);
	            } else {
	            	ps.setNull(8, Types.BLOB);
	            	ps.setNull(9, Types.VARCHAR);
	            }
	            	
	            ps.executeUpdate();
	            LoginProcessor.sendEmail(email, "Login Password", "your password is: "+password);
	            
	            request.setAttribute("feedback", "Login password has been sent to " + email + ". Please login to proceed.");
            } catch (SQLException e) {
				e.printStackTrace();
			}
        }
        RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
		rs.forward(request, response);
        
    }  
    private String extractFileName(Part part) {
		String contentDisp = part.getHeader("content-disposition");
		String[] items = contentDisp.split(";");
		for (String s : items) {
			if (s.trim().startsWith("filename")) {
				String clientFileName = s.substring(s.indexOf("=") + 2,
						s.length() - 1);
				clientFileName = clientFileName.replace("\\", "/");
				int i = clientFileName.lastIndexOf('/');
				return clientFileName.substring(i + 1);
			}
		}
		return null;
	}
}