import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;

/**
 * this is validator that validates is user already exists while registration/
 * it also validates user on login i.e. if provided credentials are correct or not
 */
public class Validate {
	
	/**
	 * this method is called in login processor to verify details entered by user
	 * 
	 * @param email: email entered by user
	 * @param pass: password entered by user
	 * @param request: to save balance and email in session on login
	 * @return: true is entered details are correct
	 */
    public static boolean checkUser(String email,String pass, HttpServletRequest request) 
    {
        boolean st = false;
        try {
            Connection con = DBUtils.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from "+Constants.DB_TABLENAME_USERS+" where email=? and password=?");
            ps.setString(1, email);
            ps.setString(2, pass);
            ResultSet rs =ps.executeQuery();
            st = rs.next();
            
            // if user exists then save balance and email in session
            if(st) {
            	request.getSession().setAttribute("balance", rs.getString("balance"));
            	request.getSession().setAttribute("email", rs.getString("email"));
            	request.getSession().setAttribute("mobile", rs.getString("mobile"));
            	request.getSession().setAttribute("username", rs.getString("name"));
            	request.getSession().setAttribute("file_name", rs.getString("file_name"));
            	request.getSession().setAttribute("document", rs.getBlob("document"));
            	request.getSession().setAttribute("sin", rs.getString("sin_no"));
            	request.getSession().setAttribute("address", rs.getString("address"));
            }
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return st;                 
    }
    
    /**
     * this method is called in case user is registering.
     * @param email: email entered by user
     * @return: true if user exits
     */
    public static boolean isUserExist(String email) 
    {
        boolean st = false;
        try {
            Connection con = DBUtils.getConnection();
            PreparedStatement ps = con.prepareStatement("select * from "+Constants.DB_TABLENAME_USERS+" where email=?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            st = rs.next();
        }
        catch(Exception e) {
            e.printStackTrace();
        }
        return st;                 
    }
}