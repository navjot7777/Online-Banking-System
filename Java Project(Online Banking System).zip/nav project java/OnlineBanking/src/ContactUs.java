import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class ContactUs extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String message = request.getParameter("message");
        
        // fetch user details and send an email to user with data that user has entered
        LoginProcessor.sendEmail(Constants.USER_EMAIL, "New Query", "You have new query to answer, following are te details:\nName: "+name+"\nEmail: "+email+"\nMessage: "+message);
        request.setAttribute("feedback", "Your query is submitted. You will be reached soon. Thank you!");
        // after entering data, redirect user to home screen
        RequestDispatcher rs = request.getRequestDispatcher("contactus.jsp");
        rs.forward(request, response);
    }  
}