import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * This is the main servlets that handles all CRUD operations.
 */
public class HandleCRUD extends HttpServlet {
    protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
    	RequestDispatcher rDispatcher = null;
    	String actionPerformed = request.getParameter("actionPerformed");
    	
    	// email is populated in session when user logins, for security reason, it is fetched from session, 
    	// so that someone cannot directly hit this servlet without login
    	Object userEmailO = request.getSession().getAttribute("email");
    	String email = null;
    	double balance = 0;
    	
    	// if user is not login, then redirect user to login page
    	if(userEmailO == null) {
    		request.getSession().setAttribute("errorMessage", "Please Login Again.");
    		rDispatcher = request.getRequestDispatcher("index.jsp");
            rDispatcher.forward(request, response);
    	} else {
    		// if user is logined then perform the operation that user has requested
    		email = userEmailO.toString();
    		
    		// in case of statement, there is no amount needed, so saving balance as it is
    		double amount = actionPerformed.equals("s") ? Double.parseDouble(request.getSession().getAttribute("balance").toString()) : Double.parseDouble(request.getParameter("amount"));
    		
    		// after every operation, redirect user to welcome page
    		String resultPage = "Welcome";
    		
    		// to perform action based on event triggered by user, i.e. deposit/withdraw/fund transfer/statement
    		switch(actionPerformed) {
    		
    		// this is for deposit
        	case "d":
        		// add amount that user has entered to user's balance and save it in balance
        		balance = amount + Double.parseDouble(request.getSession().getAttribute("balance").toString());
        		
        		// inserting credit transaction details
        		insertTransaction(email, "Credit", amount, String.valueOf(balance));
        		// updating user's balance
        		updateBalance(email, balance);
        		request.setAttribute("feedback", "$"+amount+" has been deposited");
        		break;
        		
        	// this is for withdraw
        	case "w":
        		// subtract amountr from user's balance 
        		balance = Double.parseDouble(request.getSession().getAttribute("balance").toString()) - amount;
        		
        		// inserting debit transaction details 
        		insertTransaction(email, "Debit", amount, String.valueOf(balance));
        		// updating user's balance
        		updateBalance(email, balance);
        		request.setAttribute("feedback", "$"+amount+" has been withdrawn");
        		break;
        	case "ft":
        		// email of beneficiary account
        		String bEmail = request.getParameter("email");
        		// balance of logged in user after transferring fund 
        		balance = Double.parseDouble(request.getSession().getAttribute("balance").toString()) - amount;
        		
        		// beneficiary's balance is updated with amount received
        		updateBeneficiaryBalance(bEmail, amount, email);
        		
        		// entering transfer details
        		insertTransaction(email, "Transfer to account: "+bEmail, amount, String.valueOf(balance));
        		
        		// updating balance of logged in user
        		updateBalance(email, balance);
        		request.setAttribute("feedback", "$"+amount+" has been transferred to "+bEmail);
        		break;
        	case "s":
        		// to show balance to logged in user on click of check balance button on welcome screen
        		balance = amount;
        		// start date 
        		String startDate = request.getParameter("startDate");
        		// end date
        		String endDate = request.getParameter("endDate");
        		try {
        			
        			// on database side, timestamp is used, so preparing query to fetch records based on passed dates
        		      DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        		      Date date = formatter.parse(startDate);
        		      Timestamp start = new Timestamp(date.getTime());
        		      date = formatter.parse(endDate);
        		      Timestamp end = new Timestamp(date.getTime());
        		      end.setHours(23);
        		      end.setMinutes(59);
        		      end.setSeconds(59);
        		      Connection con = DBUtils.getConnection();
        	            PreparedStatement ps = con.prepareStatement("select * from transactions where email=? and transaction_time > ? and transaction_time < ?");
        	            ps.setString(1, email);
        	            ps.setTimestamp(2, start);
        	            ps.setTimestamp(3, end);
        	            ResultSet rs =ps.executeQuery();
        	            StringBuilder stringBuilder = new StringBuilder();
        	            while(rs.next()){
        	            	stringBuilder.append("<div class=\"div-table-row\">" +
        	            							"<div class=\"div-table-col\">"+rs.getString("transaction_time")+"</div>" +
        	            							"<div class=\"div-table-col-d\">"+rs.getString("description")+"</div>" +
        	            							"<div class=\"div-table-col-a-nb\">"+rs.getString("amount")+"</div>" +
        	            							"<div class=\"div-table-col-a-nb\">"+rs.getString("balance")+"</div>" +
        	            						"</div>");
        	            }
        	            // adding prepared details to show user in statement
        	            request.getSession().setAttribute("statementData", stringBuilder.toString());
        	            
        	            // to show start date on statement page
        	            request.getSession().setAttribute("transStartDate", start);
        	            // to show end date on statement page
        	            request.getSession().setAttribute("transEndDate", end);
        	            // to redirect user to view statement
        	            resultPage = "statement.jsp";
        	            
        		    } catch (Exception e) {
        		      System.out.println("Exception :" + e);
        		    }
        		break;
        	default: 
        		rDispatcher = request.getRequestDispatcher("index.jsp");
                rDispatcher.forward(request, response);
        	}
    		
    		request.getSession().setAttribute("balance", balance);
    		rDispatcher = request.getRequestDispatcher(resultPage);
            rDispatcher.forward(request, response);
    	}
    }
    
    /**
     * This method update beneficiary account when fund is transferred to user
     * 
     * @param email: email of beneficiary
     * @param amount: amount transfered
     * @param fEmail: email of person who transferred funds
     */
	private void updateBeneficiaryBalance(String email, double amount, String fEmail) {
		Connection connection = DBUtils.getConnection();
		try {
			// to get existing balance of beneficiary
			PreparedStatement ps = connection.prepareStatement("select balance from "+Constants.DB_TABLENAME_USERS+" where email=?");
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if(rs.next()) {
            	double balance = Double.valueOf(rs.getString("balance"));
            	
            	// updating balance of beneficiary
            	updateBalance(email, (amount+balance));
            	// entering transaction for amount received by beneficiary
            	insertTransaction(email, "Transfer from account: "+fEmail, amount, String.valueOf(amount+balance));
            }
        } catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * this method inserts transaction details(credit/debit/fund transfer) in tables. 
	 * 
	 * @param email: email of acocunt whose transaction is being logged
	 * @param description: description of transaction (credit/debit/fund transfer)
	 * @param amount: amount of transaction
	 * @param balance: new balance after this transaction
	 */
	private void insertTransaction(String email, String description, double amount, String balance) {
		Connection con = DBUtils.getConnection();
		try {
        	PreparedStatement ps = con.prepareStatement("INSERT INTO transactions(email, description, amount, balance) VALUES (?,?,?,?)");
			ps.setString(1, email);
			ps.setString(2, description);
            ps.setString(3, String.valueOf(amount));
            ps.setString(4, balance);
            ps.executeUpdate();
        } catch (SQLException e) {
			e.printStackTrace();
		}
	}

	/**
	 * this method updates balance of user
	 * 
	 * @param email: email of account whose balance is to be updated
	 * @param balance: balance to be updated
	 */
	private void updateBalance(String email, double balance) {
		Connection connection = DBUtils.getConnection();
		try {
        	PreparedStatement ps = connection.prepareStatement("update "+Constants.DB_TABLENAME_USERS+" set balance=? where email=?");
			ps.setString(1, String.valueOf(balance));
			ps.setString(2, email);
            ps.executeUpdate();
        } catch (SQLException e) {
			e.printStackTrace();
		}
	}
}