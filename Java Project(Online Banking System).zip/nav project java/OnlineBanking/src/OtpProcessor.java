import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * this is otp processor servlet, that validates otp entered by user on login.
 * if otp is correct then redirect user ot welcome page to perform CRUD operations
 * else redirect user to otp page to enter correct otp  
 */
public class OtpProcessor extends HttpServlet {
 
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
        request.getSession().removeAttribute("errorMessage");
        String otp = request.getParameter("otp");
        if(request.getSession().getAttribute("email") == null){
        	RequestDispatcher rs = request.getRequestDispatcher("index.jsp");
            rs.forward(request, response);
        } else {
	        // validates otp entered by user with otp generated in LoginProcessor
	        if(request.getSession().getAttribute("otp").toString().equals(otp)) {
	        	// if otp is correct then redirect user to welcome page
	        	request.getSession().setAttribute("validUser", true);
	        	RequestDispatcher rs = request.getRequestDispatcher("Welcome");
	            rs.forward(request, response);
	        } else {
	        	// if otp is wrong then redirect user to enter otp again
	        	request.getSession().setAttribute("validUser", false);     
	        	request.getSession().setAttribute("otp", request.getSession().getAttribute("otp"));
	        	request.getSession().setAttribute("otpError", "Invalid OTP");
	        	RequestDispatcher rs = request.getRequestDispatcher("otp.jsp");
	            rs.forward(request, response);
	        }
        }
    }
}