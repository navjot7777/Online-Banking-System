import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Statement extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	String startDate = request.getParameter("startDate");
		// end date
		String endDate = request.getParameter("endDate");
		Timestamp start = null;
		Timestamp end = null;
		
		StringBuilder stringBuilder = new StringBuilder();
		try {
			// on database side, timestamp is used, so preparing query to fetch records based on passed dates
		      DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
		      Date date = formatter.parse(startDate);
		       start = new Timestamp(date.getTime());
		      date = formatter.parse(endDate);
		       end = new Timestamp(date.getTime());
		      end.setHours(23);
		      end.setMinutes(59);
		      end.setSeconds(59);
		      Connection con = DBUtils.getConnection();
	            PreparedStatement ps = con.prepareStatement("select * from transactions where email=? and transaction_time > ? and transaction_time < ?");
	            ps.setString(1, request.getSession().getAttribute("email").toString());
	            ps.setTimestamp(2, start);
	            ps.setTimestamp(3, end);
	            ResultSet rs =ps.executeQuery();
	            stringBuilder.append("<div class=\"div-table\">" +
		            "<div class=\"div-table-row\">" +
		                "<div class=\"div-table-col\">Date</div>" +
		                "<div class=\"div-table-col-d\">Description</div>" +
		                "<div class=\"div-table-col-a-nb\">Amount</div>" +
		                "<div class=\"div-table-col-a-nb\">New balance</div>" +
		             "</div>");
				
	            while(rs.next()){
	            	stringBuilder.append("<div class=\"div-table-row\">" +
	            							"<div class=\"div-table-col\">"+rs.getString("transaction_time")+"</div>" +
	            							"<div class=\"div-table-col-d\">"+rs.getString("description")+"</div>" +
	            							"<div class=\"div-table-col-a-nb\">"+rs.getString("amount")+"</div>" +
	            							"<div class=\"div-table-col-a-nb\">"+rs.getString("balance")+"</div>" +
	            						"</div>");
	            }
	            stringBuilder.append("</div>");
		    } catch (Exception e) {
		      System.out.println("Exception :" + e);
		    }
    	response.getWriter().print(start.toString().substring(0, start.toString().length()-2)+"|"+end.toString().substring(0, start.toString().length()-2)+"|"+stringBuilder.toString());
    }
}