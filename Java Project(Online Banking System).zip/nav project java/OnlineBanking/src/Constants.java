interface Constants {
	String DB_NAME = "online_banking";
	String DB_USERNAME = "root";
	String DB_PASSWORD = "";
	String DB_TABLENAME_USERS = "users";
	
	String USER_EMAIL = "nvjot7777@gmail.com";
	String USER_EMAIL_PASSWORD = "Soldier1234@";
}