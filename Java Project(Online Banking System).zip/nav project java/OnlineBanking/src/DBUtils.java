import java.sql.Connection;
import java.sql.DriverManager;

/**
 * DB utils class to get database connection
 */
public class DBUtils {
	public static Connection getConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			return DriverManager.getConnection("jdbc:mysql://localhost:3306/"
					+ Constants.DB_NAME, Constants.DB_USERNAME,
					Constants.DB_PASSWORD);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
}