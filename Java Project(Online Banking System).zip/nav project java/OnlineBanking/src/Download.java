import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Blob;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
@MultipartConfig
public class Download extends HttpServlet {

	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		try{

			ServletContext context = getServletContext();
	        // sets MIME type for the file download
			Blob blob = ((Blob)request.getSession().getAttribute("document"));
			String fileName = request.getSession().getAttribute("file_name").toString();
	        String mimeType = context.getMimeType(fileName);
	        if (mimeType == null) {        
	            mimeType = "application/octet-stream";
	        }              
	        InputStream inputStream = blob.getBinaryStream();
	        int fileLength = inputStream.available();
	        // set content properties and header attributes for the response
	        response.setContentType(mimeType);
	        response.setContentLength(fileLength);
	        String headerKey = "Content-Disposition";
	        String headerValue = String.format("attachment; filename=\"%s\"", fileName);
	        response.setHeader(headerKey, headerValue);

	        // writes the file to the client
	        OutputStream outStream = response.getOutputStream();
	         
	        byte[] buffer = new byte[4096];
	        int bytesRead = -1;
	         
	        while ((bytesRead = inputStream.read(buffer)) != -1) {
	            outStream.write(buffer, 0, bytesRead);
	        }
	         
	        inputStream.close();
	        outStream.close();      
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}