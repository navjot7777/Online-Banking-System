function showBalance() {
	$('.containers').hide();
	$("#balanceModal").show();
	$('.link_a').removeClass('active');
	$('#statement_cb').addClass('active');
}
function handleClick(clickAction, toActive) {
	$('#hideFeedback').click();
	$('.containers').hide();
	$('.link_a').removeClass('active');
	$('#enterAmountError').hide();
	var form = document.createElement("form");
	var input = document.createElement("input");
	var actionPerformed = document.createElement("input");
	isFT = false;
	input.type="hidden";
	actionPerformed.type="hidden";
	actionPerformed.name = "actionPerformed";
	
	switch(clickAction) {
	case 'h':
	    form.method = "POST";
	    form.action = "index.jsp"; 
	    
	    document.body.appendChild(form);
	    form.submit();
		break;
		
	case 'd':
			$('#'+toActive).addClass('active');
			$('#mAction').text('Deposit');
			$("#dWAmountModal").show();
		break;
		
	case 'w':
			$('#'+toActive).addClass('active');
			$('#mAction').text('Withdraw');
			$("#dWAmountModal").show();
		break;
		
	case 'ft':
			$('#'+toActive).addClass('active');
			$("#fundTransferModal").show();
		break;
		
	case 's':
			$('#'+toActive).addClass('active');
			$("#statementModal").show();
		break;
	default:
		form.method = "GET";
    	form.action = "login.jsp";   
	}
}
function ExportPdf(){ 
kendo.drawing
    .drawDOM("#content", 
    { 
        paperSize: "A4",
        margin: { top: "1cm", bottom: "1cm", left:"1cm" },
        scale: 0.8,
        height: 500
    })
        .then(function(group){
        kendo.drawing.pdf.saveAs(group, "statement.pdf")
    });
}
function goToHome() {
	$('#statementModal').show();
	$('#statementResult').hide();
}
function logout() {
	var form = document.createElement("form");
	form.method = "POST";
	form.action = "logout";
	document.body.appendChild(form);
    form.submit();
}
function downloadFile(){
	var url = "download";
    var xmlhttp;

    if (window.XMLHttpRequest) {// code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    } else {// code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function() {
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
        }
    }

    xmlhttp.open("GET", url, true);
    xmlhttp.send();

    var elemIF = document.createElement("iframe");
    elemIF.src = url;
    elemIF.style.display = "none";
    document.body.appendChild(elemIF);
}